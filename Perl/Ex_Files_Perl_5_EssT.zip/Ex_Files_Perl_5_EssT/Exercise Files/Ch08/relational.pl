#!/usr/bin/perl
# relational.pl by Bill Weinman <http://bw.org/contact/>

use 5.18.0;
use warnings;

my $a = 7;
my $b = 42;
my $c = 7;
my $d = 42;

if ( $a == $b ) {
    say 'true';
} else {
    say 'false';
}


