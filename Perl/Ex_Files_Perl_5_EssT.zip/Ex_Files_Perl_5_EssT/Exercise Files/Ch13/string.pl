#!/usr/bin/perl
# string.pl by Bill Weinman <http://bw.org/contact/>

use 5.18.0;
use warnings;

my $string = "This string has a bunch of useful characters in it.";
say $string;
