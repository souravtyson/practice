#!/usr/bin/perl
# num.pl by Bill Weinman <http://bw.org/contact/>

use 5.18.0;
use warnings;

my $a = 47;
my $b = 150;

my $x = $a + $b;

say "result is: $x";
